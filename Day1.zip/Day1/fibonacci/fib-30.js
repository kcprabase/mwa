const fib = require('./fibonacci');

console.log("Fibonacci of -30 is", fib(-30));