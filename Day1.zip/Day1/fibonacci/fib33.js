const fib = require('./fibonacci');

console.log("Fibonacci of 33 is", fib(33));